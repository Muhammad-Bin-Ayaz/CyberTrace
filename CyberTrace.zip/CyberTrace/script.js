
"use strict";

const $ = (selector) => document.querySelector(selector);

const STORAGE_KEYS = {
  cases: "cybertrace_cases_v1",
  evidence: "cybertrace_evidence_v1"
};

function readRecords(key) {
  try {
    const data = JSON.parse(localStorage.getItem(key) || "[]");
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

let cases = readRecords(STORAGE_KEYS.cases);
let evidence = readRecords(STORAGE_KEYS.evidence);
let toastTimeout;

function saveRecords() {
  try {
    localStorage.setItem(STORAGE_KEYS.cases, JSON.stringify(cases));
    localStorage.setItem(STORAGE_KEYS.evidence, JSON.stringify(evidence));
    return true;
  } catch {
    showToast("Unable to save. Check your browser storage settings.");
    return false;
  }
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  })[character]);
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Unknown"
    : date.toLocaleDateString(undefined, {
        year: "numeric",
        month: "short",
        day: "numeric"
      });
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove("show"), 3200);
}

/* Loading screen and welcome popup */
function startLoading() {
  const loader = $("#loader");
  const progress = $("#progress-bar");
  const loadingText = $("#loading-text");
  const messages = [
    "Establishing secure workspace...",
    "Preparing investigation records...",
    "Loading dashboard components...",
    "Workspace ready."
  ];

  const start = performance.now();
  const duration = 2300;

  function update(now) {
    const fraction = Math.min((now - start) / duration, 1);
    const percent = Math.round(fraction * 100);

    progress.style.width = `${percent}%`;
    loadingText.textContent =
      messages[Math.min(Math.floor(fraction * messages.length), messages.length - 1)];

    if (fraction < 1) {
      requestAnimationFrame(update);
    } else {
      loader.classList.add("done");
      $("#welcome-modal").classList.remove("hidden");
    }
  }

  requestAnimationFrame(update);
}

$("#enter-btn").addEventListener("click", () => {
  $("#welcome-modal").classList.add("hidden");
  document.body.classList.add("dashboard-ready");
  showToast("Welcome to CyberTrace. Your workspace is ready.");
});

/* Date */
$("#today-date").textContent = new Date().toLocaleDateString(undefined, {
  weekday: "short",
  year: "numeric",
  month: "short",
  day: "numeric"
});

/* Navigation highlighting */
document.querySelectorAll(".nav-link").forEach((link) => {
  link.addEventListener("click", () => {
    document.querySelectorAll(".nav-link").forEach((item) => {
      item.classList.remove("active");
    });
    link.classList.add("active");
  });
});

/* Case management */
const caseForm = $("#case-form");

function showCaseForm() {
  caseForm.classList.remove("hidden");
  $("#case-title").focus();
}

$("#new-case-btn").addEventListener("click", showCaseForm);
$("#new-case-top").addEventListener("click", showCaseForm);

$("#cancel-case").addEventListener("click", () => {
  caseForm.reset();
  caseForm.classList.add("hidden");
});

caseForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const title = $("#case-title").value.trim();
  const priority = $("#case-priority").value;

  if (!title) {
    showToast("Please enter a case title.");
    return;
  }

  const record = {
    id: `CT-${Date.now().toString().slice(-7)}`,
    title,
    priority,
    status: "Open",
    createdAt: new Date().toISOString()
  };

  cases.unshift(record);

  if (!saveRecords()) {
    cases.shift();
    return;
  }

  caseForm.reset();
  caseForm.classList.add("hidden");
  renderCases();
  showToast("Investigation case created.");
});

$("#case-search").addEventListener("input", renderCases);
$("#case-filter").addEventListener("change", renderCases);

function renderCases() {
  const tbody = $("#cases-table");
  const query = $("#case-search").value.trim().toLowerCase();
  const filter = $("#case-filter").value;

  const filtered = cases.filter((record) => {
    const matchesQuery =
      record.title.toLowerCase().includes(query) ||
      record.id.toLowerCase().includes(query);

    return matchesQuery && (filter === "all" || record.status === filter);
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" class="empty-state">
          ${cases.length ? "No cases match your search." : "No cases yet. Create your first investigation."}
        </td>
      </tr>`;
    updateStats();
    return;
  }

  tbody.innerHTML = filtered.map((record) => {
    const safeId = escapeHTML(record.id);
    const safeTitle = escapeHTML(record.title);
    const safePriority = escapeHTML(record.priority);
    const safeStatus = escapeHTML(record.status);
    const statusClass = record.status.replace(/\s+/g, "-");

    return `
      <tr>
        <td>
          <strong>${safeTitle}</strong>
          <span class="case-id">${safeId}</span>
        </td>
        <td><span class="priority ${safePriority}">${safePriority}</span></td>
        <td><span class="case-status ${statusClass}">${safeStatus}</span></td>
        <td>${escapeHTML(formatDate(record.createdAt))}</td>
        <td>
          <div class="action-group">
            <button class="small-action" data-action="status" data-id="${safeId}">
              ${record.status === "Closed" ? "Reopen" : "Update"}
            </button>
            <button class="small-action delete" data-action="delete" data-id="${safeId}">
              Delete
            </button>
          </div>
        </td>
      </tr>`;
  }).join("");

  updateStats();
}

$("#cases-table").addEventListener("click", (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const record = cases.find((item) => item.id === button.dataset.id);
  if (!record) return;

  if (button.dataset.action === "status") {
    const oldStatus = record.status;
    const nextStatus = {
      "Open": "In Progress",
      "In Progress": "Closed",
      "Closed": "Open"
    };

    record.status = nextStatus[record.status] || "Open";

    if (!saveRecords()) {
      record.status = oldStatus;
      return;
    }

    renderCases();
    showToast(`Case status changed to ${record.status}.`);
  }

  if (button.dataset.action === "delete") {
    if (!confirm(`Delete case "${record.title}"? This cannot be undone.`)) return;

    const previous = cases;
    cases = cases.filter((item) => item.id !== record.id);

    if (!saveRecords()) {
      cases = previous;
      return;
    }

    renderCases();
    showToast("Case deleted.");
  }
});

/* Evidence vault */
const evidenceForm = $("#evidence-form");

$("#add-evidence-btn").addEventListener("click", () => {
  evidenceForm.classList.remove("hidden");
  $("#evidence-title").focus();
});

$("#cancel-evidence").addEventListener("click", () => {
  evidenceForm.reset();
  evidenceForm.classList.add("hidden");
});

evidenceForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const title = $("#evidence-title").value.trim();
  const type = $("#evidence-type").value;
  const notes = $("#evidence-notes").value.trim();

  if (!title) {
    showToast("Please enter an evidence title.");
    return;
  }

  const record = {
    id: `EV-${Date.now().toString().slice(-7)}`,
    title,
    type,
    notes,
    createdAt: new Date().toISOString()
  };

  evidence.unshift(record);

  if (!saveRecords()) {
    evidence.shift();
    return;
  }

  evidenceForm.reset();
  evidenceForm.classList.add("hidden");
  renderEvidence();
  showToast("Evidence record saved.");
});

function renderEvidence() {
  const container = $("#evidence-list");

  if (evidence.length === 0) {
    container.innerHTML = '<div class="empty-state">No evidence records added yet.</div>';
    updateStats();
    return;
  }

  container.innerHTML = evidence.map((record) => `
    <article class="evidence-card">
      <div class="evidence-card-top">
        <span class="evidence-symbol">◈</span>
        <span class="evidence-type">${escapeHTML(record.type)}</span>
      </div>
      <h3>${escapeHTML(record.title)}</h3>
      <p>${escapeHTML(record.notes || "No additional notes.")}</p>
      <p class="evidence-date">${escapeHTML(formatDate(record.createdAt))}</p>
      <button class="small-action delete" data-evidence-delete="${escapeHTML(record.id)}">
        Delete record
      </button>
    </article>
  `).join("");

  updateStats();
}

$("#evidence-list").addEventListener("click", (event) => {
  const button = event.target.closest("[data-evidence-delete]");
  if (!button) return;

  const id = button.dataset.evidenceDelete;
  const record = evidence.find((item) => item.id === id);
  if (!record) return;

  if (!confirm(`Delete evidence record "${record.title}"?`)) return;

  const previous = evidence;
  evidence = evidence.filter((item) => item.id !== id);

  if (!saveRecords()) {
    evidence = previous;
    return;
  }

  renderEvidence();
  showToast("Evidence record deleted.");
});

/* Dashboard statistics */
function updateStats() {
  $("#active-count").textContent =
    cases.filter((record) => record.status !== "Closed").length;

  $("#closed-count").textContent =
    cases.filter((record) => record.status === "Closed").length;

  $("#evidence-count").textContent = evidence.length;
}

/* Map setup */
let map = null;
let locationMarker = null;

function initializeMap() {
  if (typeof L === "undefined") {
    $("#map-message").textContent =
      "Map library could not load. Check your internet connection and reload.";
    return;
  }

  map = L.map("map", {
    zoomControl: true,
    scrollWheelZoom: false
  }).setView([24.8607, 67.0011], 11);

  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);

  locationMarker = L.marker([24.8607, 67.0011])
    .addTo(map)
    .bindPopup("Map starting view: Karachi");

  setTimeout(() => map.invalidateSize(), 250);
}

$("#location-form").addEventListener("submit", async (event) => {
  event.preventDefault();

  const query = $("#location-input").value.trim();
  const message = $("#map-message");
  const button = $("#location-form button");

  if (!query || !map) {
    if (!map) showToast("Map is unavailable. Check your internet connection.");
    return;
  }

  message.textContent = "Searching public map data...";
  button.disabled = true;
  button.textContent = "Searching...";

  try {
    const url = new URL("https://nominatim.openstreetmap.org/search");
    url.searchParams.set("q", query);
    url.searchParams.set("format", "jsonv2");
    url.searchParams.set("limit", "1");

    const response = await fetch(url.toString(), {
      headers: { "Accept": "application/json" }
    });

    if (!response.ok) throw new Error("Search request failed");

    const results = await response.json();

    if (!results.length) {
      message.textContent = "No matching public location found. Try a different search.";
      return;
    }

    const result = results[0];
    const lat = Number(result.lat);
    const lon = Number(result.lon);

    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      throw new Error("Invalid map coordinates");
    }

    map.setView([lat, lon], 14);

    if (locationMarker) map.removeLayer(locationMarker);

    locationMarker = L.marker([lat, lon])
      .addTo(map)
      .bindPopup(escapeHTML(result.display_name))
      .openPopup();

    message.textContent = `Location found: ${result.display_name}`;
  } catch {
    message.textContent =
      "Unable to search right now. Check your connection and try again.";
  } finally {
    button.disabled = false;
    button.textContent = "Find Location";
  }
});

/* Export a report */
$("#export-report").addEventListener("click", () => {
  const lines = [
    "CYBERTRACE — INVESTIGATION SUMMARY",
    `Generated: ${new Date().toLocaleString()}`,
    "Created by: Muhammad Bin Ayaz",
    "",
    "CASE REGISTER",
    "============="
  ];

  if (!cases.length) {
    lines.push("No cases recorded.");
  } else {
    cases.forEach((record, index) => {
      lines.push(
        `${index + 1}. ${record.title}`,
        `   ID: ${record.id}`,
        `   Priority: ${record.priority}`,
        `   Status: ${record.status}`,
        `   Created: ${formatDate(record.createdAt)}`,
        ""
      );
    });
  }

  lines.push("", "EVIDENCE REGISTER", "=================");

  if (!evidence.length) {
    lines.push("No evidence records.");
  } else {
    evidence.forEach((record, index) => {
      lines.push(
        `${index + 1}. ${record.title}`,
        `   ID: ${record.id}`,
        `   Type: ${record.type}`,
        `   Notes: ${record.notes || "None"}`,
        `   Created: ${formatDate(record.createdAt)}`,
        ""
      );
    });
  }

  lines.push(
    "",
    "END OF REPORT",
    "This report contains records entered into this browser workspace."
  );

  const blob = new Blob([lines.join("\n")], {
    type: "text/plain;charset=utf-8"
  });

  const downloadUrl = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = downloadUrl;
  link.download = `CyberTrace-Report-${new Date().toISOString().slice(0, 10)}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(downloadUrl);

  showToast("Investigation report exported.");
});

/* Start application */
renderCases();
renderEvidence();
initializeMap();
startLoading();
